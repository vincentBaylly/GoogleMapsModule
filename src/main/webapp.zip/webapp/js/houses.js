var houses = [
    {
        centris: 22026771,
        price: 89500,
        title: "7 Pièces 3 Chambres 1 Salle de bain/d'eau",
        address: "2182 Rue Bellevue, Shawinigan G9N 3K6",
        estielect: 197,
        latitude: 46.5656704,
        longitude: -72.7459333,
        taxesmun: 1299,
        taxesscol: 192,
        taxestotal: 1491
    },
    {
        centris: 21932902,
        price: 79900,
        title: "8 Pièces 3 Chambres 1 Salle de bain/d'eau",
        address: "5141 Avenue Tour-du-Lac, Lac-à-la-Tortue G0X 1L0",
        estielect: 192,
        latitude: 46.6171553,
        longitude: -72.6153116,
        taxesmun: 1705,
        taxesscol: 306,
        taxestotal: 2011
    },
    {
        centris: 11326605,
        price: 89900,
        title: "12 Pièces 4 Chambres 1 Salle de bain/d'eau",
        address: "1980 Ch. Principal, Saint-Gerard-des-Laurentides G9R 1E9",
        estielect: 225,
        latitude: 46.620134,
        longitude: -72.8269278,
        taxesmun: 1625,
        taxesscol: 292,
        taxestotal: 1917
    },
    {
    	centris: 10854966,
        price: 94900,
        title: "9 Pièces 5 Chambres 2 Salles de bain/d'eau",
        address: "650 7e Avenue, Grand-Mère G9T 2B4",
        estielect: 222,
        latitude: 46.620134,
        longitude: -72.8269278,
        taxesmun: 1521,
        taxesscol: 269,
        taxestotal: 1790
    },
    {
        centris: 10743379,
        price: 109300,
        title:"10 Pièces 2 Chambres 2 Salles de bain/d'eau",
        address: "555 112e Rue, Shawinigan-Sud G9P 2V7",
        estielect: 252,
        latitude: 46.5237543,
        longitude: -72.7520344,
        taxesmun: 1825,
        taxesscol: 288,
        taxestotal: 2140
    },
    {
        centris: 23173310,
        price: 92500,
        title:"11 Pièces 5 Chambres 1 Salle de bain/d'eau",
        address: "900, 4e Avenue, Grand-Mère G9T 2S2",
        estielect: 140,
        latitude: 46.6103721,
        longitude: -72.6948823,
        taxesmun: 1614,
        taxesscol: 286,
        taxestotal: 1900
    },
    {
        centris: 24793356,
        price: 89900,
        title:"13 Pièces 4 Chambres 2 Salles de bain/d'eau",
        address: "461 19E Avenue, Grand-Mère G9T 1B8",
        estielect: 229,
        latitude: 46.6220772,
        longitude: -72.700222,
        taxesmun: 1570,
        taxesscol: 283,
        taxestotal: 1853
    }
]